ptmTestViewer = {
	tests : {},
	artifactsRepository : 'http://sswhli474:8020/artifacts/',
	testsRepository : '/artifacts/tests/',
	chartsCount : 0,
	plots : [],
	eLoggingTests : [],
	environments : [],

	initialize : function() {
		$.jqplot.config.enablePlugins = true;

		$.ajax('testsList').done(function(data) {
			ptmTestViewer.environments = data.sort().reverse();
			ptmTestViewer.addNewChartBox();
			var chartCanvas = $('<div class="spacer"><div id="chart_canvas" class="chartCanvas"></div></div>');
			$('#shadowtailChartsContainer').append(chartCanvas);

		})

	},
	addNewChartBox : function() {
		var chartBox = ptmTestViewer.createChartBox();
		var container = $('#shadowtailChartsContainer');
		container.append(chartBox);
		this.chartsCount++;
	},
	createChartBox : function() {
		var chartBox = $('<div id="chart_box" class="chartBox"></div>');
		var testsSelect = $('<select class="chart_testsSelect select"></select>');
		var eventsTableWrapper = $('<div class="spacer"></div>');

		testsSelect.change(function() {
			ptmTestViewer.testSelectionChange(testsSelect, eventsTableWrapper);
		});

		var id = this.chartsCount;
		ptmTestViewer.populateAvailableTests(testsSelect, id);

		var drawButton = $('<button id="chart_drawButton_' + this.chartsCount + ' type="button" class="button">Redraw</button>');
		drawButton.click(function() {
			ptmTestViewer.redrawChart_fromTableSelection(id);
		});

		var clearSelectionButton = $('<button id="chart_clearSelectionButton_' + this.chartsCount + ' type="button" class="button">Clear selection</button>');
		clearSelectionButton.click(function() {
			ptmTestViewer.selectedCharts = undefined;
			$('table tbody tr td.selectedEvent').each(function() {
				$(this).removeClass('selectedEvent');
			})
		});

		var additionalTests = $('<button type="button" class="button">Additional test</button>');
		additionalTests.click(ptmTestViewer.addNewChartBox);

		chartBox.append(testsSelect);
		chartBox.append(drawButton);
		chartBox.append(clearSelectionButton);
		chartBox.append(additionalTests);
		// chartBox.append(additionalTestButton);

		chartBox.append(eventsTableWrapper);
		// chartBox.append(additionalTests);

		return chartBox;
	},
	compareTests : function(tests, text) {
		return $('<option value="' + value + '">' + text + '</option>');
	},
	createSelectOption : function(value, text) {
		return $('<option value="' + value + '">' + text + '</option>');
	},

	populateAvailableCompareTests : function(testsSelect) {
		for (var i = 0; i < ptmTestViewer.eLoggingTests.length; i++) {
			var value = ptmTestViewer.eLoggingTests[i];
			testsSelect.append($('<option value="' + value + '">' + value + '</option>'));
		}
	},
	populateAvailableTests : function(testsSelect, id) {

		testsSelect.data({
			id : this.chartsCount
		});

		testsSelect.append(this.createSelectOption('', 'select env ...'));
		var i = 0;
		for (i = 0; i < ptmTestViewer.environments.length; i++) {
			var value = ptmTestViewer.environments[i];
			testsSelect.append(this.createSelectOption(value, value));
		}
	},
	createNewCanvas : function() {
		var canvas = $('#chart_canvas');
		var newCanvas = $('<div id="chart_canvas" class="chartCanvas"></div>');
		canvas.replaceWith(newCanvas);

	},
	prepareStatisticsForTableRendering : function(selctedTestId) {

		var selectedTest = ptmTestViewer.tests[selctedTestId];
		var config = selectedTest.config;
		var aggregationTypes = config.aggregationTypes;
		var types = selectedTest.eventTypes;

		var tableDataSet = [];
		for ( var idx in types) {
			var type = types[idx];
			var names = ptmTestViewer.tests[selctedTestId]['type'][type].eventNames;
			var j = 0;
			for (j = 0; j < names.length; j++) {

				var eventData = ptmTestViewer.tests[selctedTestId]['type'][type][names[j]];
				var statistics = eventData.statistics;
				var errorRate = 0;
				if (statistics.CNT == 0) {
					errorRate = 100.00;
				} else {
					errorRate = (statistics.ERR / statistics.CNT * 100).toFixed(2);
				}
				var eventDataForTable = [ type, names[j] ];
				for ( var aIdx in aggregationTypes) {
					eventDataForTable.push(statistics[aggregationTypes[aIdx]]);
				}
				eventDataForTable.push(errorRate);
				tableDataSet.push(eventDataForTable);
			}
		}
		return tableDataSet;

	},
	parseProperties : function(data) {
		var testConfig = {};
		var lines = data.split('\n');
		for (var i = 0; i < lines.length; i++) {
			var line = lines[i];
			var lineSplit = line.split('=');
			var name = lineSplit[0];
			testConfig[lineSplit[0]] = lineSplit[1];

		}
		return testConfig;
	},
	getGcLogs : function(testJSON) {

		testJSON.gcLogs = new Array();

		for (var targetIdx = 0; targetIdx < testJSON.targetsList.length; targetIdx++) {
			var targetName = testJSON.targetsList[targetIdx];
			var targetJSON = testJSON.targets[targetName];
			var targetPropetries = targetJSON.targetPropetries;
			var testProperties = testJSON.testPropeties;

			targetJSON.gcLogs = new Array();

			for (var t = 0; t < targetJSON.tiers.length; t++) {
				var tier = targetJSON.tiers[t];
				var backup = testProperties[targetName + '.' + tier + '.gcLog.backup'];
				var report = testProperties[targetName + '.' + tier + '.gcLog.report'];
				var gcLog = {
					target : targetName,
					tier : tier,
					gcLogBackup : backup,
					gcLogReport : report
				}
				targetJSON.gcLogs.push(gcLog);
				testJSON.gcLogs.push(gcLog);

			}
		}

	},
	getAWR : function(testJSON) {

		testJSON.awrs = new Array();

		for (var targetIdx = 0; targetIdx < testJSON.targetsList.length; targetIdx++) {
			var targetName = testJSON.targetsList[targetIdx];
			var targetJSON = testJSON.targets[targetName];
			var targetPropetries = targetJSON.targetPropetries;
			var testProperties = testJSON.testPropeties;

			var AWR = {
				target : targetName,
				awr : targetPropetries[targetName + '.db.awr']
			};
			testJSON.awrs.push(AWR);

		}

	},
	getThreadDumps : function(testJSON) {

		testJSON.threadDumps = new Array();

		for (var targetIdx = 0; targetIdx < testJSON.targetsList.length; targetIdx++) {
			var targetName = testJSON.targetsList[targetIdx];
			var targetJSON = testJSON.targets[targetName];
			var targetPropetries = targetJSON.targetPropetries;
			var testProperties = testJSON.testPropeties;

			targetJSON.threadDumps = new Array();

			for (var t = 0; t < targetJSON.tiers.length; t++) {
				var tier = targetJSON.tiers[t];

				var td = testProperties[targetName + '.' + tier + '.threadDumps'];
				td = {
					target : targetName,
					tier : tier,
					threadDumps : td,
				};

				targetJSON.threadDumps.push(td);
				testJSON.threadDumps.push(td);
			}
		}

	},
	getShadowtailStatsTable : function(shadowtailReport) {

		var headersOrder = new Array();
		headersOrder.push("Process-Cpu-Utilization");
		headersOrder.push("Server-Load");
		headersOrder.push("Heap-Memory-Used");
		headersOrder.push("Throughput");
		headersOrder.push("Throughput-5sec");
		headersOrder.push("JVM-Thread-Count");
		headersOrder.push("https-Threads-Busy");
		headersOrder.push("https-Threads-Count");
		headersOrder.push("http-Threads-Busy");
		headersOrder.push("http-Threads-Count");
		headersOrder.push("Loaded-Class-Count");
		headersOrder.push("Unloaded-Class-Count");
		headersOrder.push("GC-CMS-Count");
		headersOrder.push("GC-CMS-Time");
		headersOrder.push("GC-ParNew-Count");
		headersOrder.push("GC-ParNew-Time");

		var measurementMap = {
			"Loaded-Class-Count" : "MAX",
			"Unloaded-Class-Count" : "MAX",
			"Heap-Memory-Used" : "50th",

			"GC-CMS-Count" : "MAX",
			"GC-CMS-Time" : "MAX",
			"GC-ParNew-Count" : "MAX",
			"GC-ParNew-Time" : "MAX",

			"GC-PS-MarkSweep-Count" : "MAX",
			"GC-PS-MarkSweep-Time" : "MAX",
			"GC-PS-Scavenge-Count" : "MAX",
			"GC-PS-Scavenge-Time" : "MAX",

			"JVM-Thread-Count" : "50th",
			"Server-Load" : "50th",
			"Process-Cpu-Utilization" : "50th",
			"Throughput" : "MIN",
			"Throughput-5sec" : "50th",
			"http-Threads-Busy" : "50th",
			"http-Threads-Count" : "50th",
			"Active-Sessions-Count" : "50th",
			"Session-Create-Rate" : "50th",
			"Session-Expire-Rate" : "50th",
			"Session-AVG-Alive-Time" : "50th",
			"https-Threads-Busy" : "50th",
			"https-Threads-Count" : "50th",
			"GC-PS-MarkSweep-Count" : "MAX",
			"GC-PS-MarkSweep-Time" : "MAX",
			"GC-PS-Scavenge-Count" : "MAX",
			"GC-PS-Scavenge-Time" : "MAX",
			"ThreadPool-Cars-Rejected" : "MAX",
			"ThreadPool-Booking-Rejected" : "MAX",
			"ThreadPool-Minibooker-Rejected" : "MAX",
			"ThreadPool-Profiles-Rejected" : "MAX",
			"ThreadPool-LFS-Rejected" : "MAX"
		}

		var headers = shadowtailReport.split("\n")[0].split(",");
		var stats = $.csv.toObjects(shadowtailReport, {
			separator : ","
		});

		var statsHolder = $('<div/>')

		var statsTable = $('<table cellpadding="5px" border="1" class="artifactTable"></table>');
		statsHolder.append(statsTable);
		var tr = $('<tr/>');
		statsTable.append(tr);
		for (var i = 0; i < headersOrder.length; i++) {
			tr.append($('<th>' + headersOrder[i] + ' (' + measurementMap[headersOrder[i]] + ')</th>'));
		}

		tr = $('<tr/>');
		statsTable.append(tr);
		for (var i = 0; i < headersOrder.length; i++) {

			var found = false;
			for (var s = 0; s < stats.length; s++) {
				if (stats[s].Name == headersOrder[i]) {
					found = true;
					if (stats[s]) {
						val = stats[s][measurementMap[stats[s].Name]];
						if ("Heap-Memory-Used" == stats[s].Name) {
							val = val / 1024 / 1024;
						}
						tr.append($('<td>' + val + '</td>'));
					} else {
						tr.append($('<td>-</td>'));
					}
				}
			}
			if (!found) {
				tr.append($('<td>-</td>'));
			}

		}
		statsTable = $('<table cellpadding="5px" border="1" class="artifactTable"></table>');
		statsHolder.append(statsTable);
		var headRow = $('<tr/>');
		var tr = $('<tr/>');
		statsTable.append(headRow);
		statsTable.append(tr);

		for (var s = 0; s < stats.length; s++) {
			if (headersOrder.indexOf(stats[s].Name) == -1) {
				var type = measurementMap[stats[s].Name];
				if (!type) {
					type = "50th";
				}
				headRow.append($('<th>' + stats[s].Name + ' (' + type + ')</th>'));

				val = stats[s][type];
				tr.append($('<td>' + val + '</td>'));

			}
		}

		return statsHolder;
	},
	getShadowtail : function(testJSON) {

		testJSON.shadowtail = new Array();

		for (var targetIdx = 0; targetIdx < testJSON.targetsList.length; targetIdx++) {
			var targetName = testJSON.targetsList[targetIdx];
			var targetJSON = testJSON.targets[targetName];
			var targetPropetries = targetJSON.targetPropetries;
			var testProperties = testJSON.testPropeties;

			targetJSON.shadowtail = new Array();

			var target = targetName;
			var tiers = targetJSON.tiers;
			for (var t = 0; t < targetJSON.tiers.length; t++) {
				var tier = targetJSON.tiers[t];

				var log = testProperties[target + '.' + tier + '.shadowtail.log'];
				var report = testProperties[target + '.' + tier + '.shadowtail.report'];

				var shad = {
					target : target,
					tier : tier,
					log : log,
					report : report
				};

				$.ajax({
					type : "GET",
					url : '/' + report,
					shadowtail : shad
				}).done(function(data) {
					console.log('got shadowtail report');
					shad.reportCSV = data;
					if (shad.spinner) {
						shad.spinner.stop();
						$(shad.spinner).replaceWith(ptmTestViewer.getShadowtailStatsTable(data));
						shad.spinner = undefined;
					}
				});

				targetJSON.shadowtail.push(shad);
				testJSON.shadowtail.push(shad);
			}

		}
		return testJSON.shadowtail
	},
	getELoggingCharts : function(testJSON) {

		testJSON.eLoggingCharts = new Array();

		for (var targetIdx = 0; targetIdx < testJSON.targetsList.length; targetIdx++) {
			var targetName = testJSON.targetsList[targetIdx];
			var targetJSON = testJSON.targets[targetName];
			var targetPropetries = targetJSON.targetPropetries;
			var testProperties = testJSON.testPropeties;

			targetJSON.eLoggingCharts = new Array();

			var target = targetName;
			var tiers = targetJSON.tiers;
			for (var t = 0; t < tiers.length; t++) {
				var tier = tiers[t];
				var apps = targetPropetries[tier + '.apps'].split(";");
				for (a = 0; a < apps.length; a++) {
					var app = apps[a];
					var eLogChartLocation = testProperties[target + '.' + tier + '.' + app + '.eLoggingCharts'];
					if (eLogChartLocation) {
						var eLogChart = {
							target : target,
							tier : tier,
							app : app,
							eData : eLogChartLocation
						};
						targetJSON.eLoggingCharts.push(eLogChart);
						testJSON.eLoggingCharts.push(eLogChart);

					}

				}

			}

		}

		return testJSON.eLoggingCharts;

	},
	createSpinner : function() {
		var spin = $('<div/>');
		var opts = {
			lines : 13, // The number of lines to draw
			length : 8, // The length of each line
			width : 2, // The line thickness
			radius : 0, // The radius of the inner circle
			corners : 1, // Corner roundness (0..1)
			rotate : 34, // The rotation offset
			direction : 1, // 1: clockwise, -1: counterclockwise
			color : 'black', // #rgb or #rrggbb or array of colors
			speed : 0.7, // Rounds per second
			trail : 47, // Afterglow percentage
			shadow : false, // Whether to render a shadow
			hwaccel : false, // Whether to use hardware acceleration
			className : 'spinner', // The CSS class to assign to the
			// spinner
			zIndex : 2e9, // The z-index (defaults to 2000000000)
			top : 'auto', // Top position relative to parent in px
			left : 'auto' // Left position relative to parent in px
		};

		spin.spin(opts);
		return spin;
	},
	renderEloggingCharts : function(testJSON) {
		var eCharts = $('<div class="spacer"/>');
		eCharts.append($('<div class="medium-boxHeader">eLoggingCharts</div>'));
		var echartsTable = $('<table cellpadding="5px" border="1" class="artifactTable"></table>');
		echartsTable.append($('<tr><th>target</th><th>tier</th><th>app</th><th>Statistics</th><th>Errors</th><th>Validation</th></tr>'));

		eCharts.append(echartsTable);
		for (var g = 0; g < testJSON.eLoggingCharts.length; g++) {
			var chart = testJSON.eLoggingCharts[g];
//			echartsTable.append($('<tr><td>' + chart.target + '</td> <td>' + chart.tier + '</td> <td><a href="' + chart.eData + '">' + chart.app + '</a></td></tr>'));

			var tr = $('<tr/>');

			tr.append($('<td>' + chart.target + '</td>'));
			tr.append($('<td>' + chart.tier + '</td>'));
			tr.append($('<td>' + chart.app + '</td>'));
			
			var data = '/'+chart.eData;
			tr.append($('<td><a href="' + data+'/statistics.csv">statistics.csv</a></td>'));
			tr.append($('<td><a href="' + data+'/errors.csv">errors.csv</a></td>'));
			tr.append($('<td><a href="' + data+'/validation.csv">validation.csv</a></td>'));
			
			echartsTable.append(tr);
		}

		return eCharts;
	},
	renderShadowtail : function(testJSON) {
		var shadowtail = $('<div class="spacer "/>');
		shadowtail.append($('<div class="medium-boxHeader">Shadowtail</div>'));
		var shadowtailTable = $('<table id="shadowtailTable-' + testJSON.testId + '" cellpadding="5px" border="1" class="artifactTable"></table>');
		shadowtail.append(shadowtailTable);
		shadowtailTable.append($('<tr><th>target</th><th>tier</th><th>log</th><th>report</th><th>Statistics</th></tr>'));

		for (var g = 0; g < testJSON.shadowtail.length; g++) {
			var shad = testJSON.shadowtail[g];
			var tr = $('<tr/>');

			tr.append($('<td>' + shad.target + '</td>'));
			tr.append($('<td><a href="' + ptmTestViewer.artifactsRepository + 'shadowtail/' + shad.target + '-' + shad.tier + '/report.csv" >' + shad.tier + '</a></td>'));
			tr.append($('<td>><a href="/' + shad.log + '">shadowtail.log</a></td>'));
			tr.append($('<td>><a href="/' + shad.report + '">report</a></td>'));

			var toClick = $('<td></td>');

			if (shad.reportCSV) {
				toClick.test(shad.reportCSV);
				console.log('appended report');
			} else {

				var spinner = ptmTestViewer.createSpinner();
				toClick.append(spinner);
				shad.spinner = spinner;
			}

			// toClick.click(shad, function(event){
			// alert(event.data.log); $(this).text(event.data.reportCSV)}
			// );
			tr.append(toClick);
			shadowtailTable.append(tr);
			// shadowtailTable.append($('<tr><td>' + shad.target + '</td> <td>'
			// + shad.tier + '</td> <td><a href="/' + shad.log +
			// '">shadowtail.log</a></td><td><a href="/' + shad.report +
			// '">shadowtail report</a></td></tr>'));
		}

		return shadowtail;
	},
	renderArtifacts : function(eventsTableWrapper, testJSON) {

		eventsTableWrapper.find('*').remove();
		var summary = $('<div id="summary" class="spacer"/>');

		var tableSummary = $('<table cellpadding="5px" border="1" class="artifactTable"></table>');
		tableSummary.append($('<tr><td>Test Tag:</td> <td>' + testJSON.testTag + '</td></tr>'));
		tableSummary.append($('<tr><td>Test Id:</td> <td>' + testJSON.testId + '</td></tr>'));
		tableSummary.append($('<tr><td>Test start:</td> <td>' + testJSON.testStart + '</td></tr>'));
		if (testJSON.testStop) {
			tableSummary.append($('<tr><td>Test stop:</td> <td> ' + testJSON.testStop + '</td></tr>'));
		} else {
			tableSummary.append($('<tr><td>Test cancel:</td> <td> ' + testJSON.testCancel + '</td></tr>'));
		}

		summary.append(tableSummary);

		eventsTableWrapper.append(summary);

		var artifacts = $('<div id="artifacts" class="spacer"/>');
		artifacts.append($('<div class="boxHeader">Artifacts</div>'));

		var shadowtail = ptmTestViewer.renderShadowtail(testJSON);
		artifacts.append(shadowtail);

		var gcLogsRender = ptmTestViewer.renderGcLogs(testJSON);
		artifacts.append(gcLogsRender);

		var eCharts = ptmTestViewer.renderEloggingCharts(testJSON);
		artifacts.append(eCharts);

		var threadDumps = $('<div class="spacer "/>');
		threadDumps.append($('<div class="medium-boxHeader">Thread Dumps</div>'));
		var tdTable = $('<table cellpadding="5px" border="1" class="artifactTable"></table>');
		threadDumps.append(tdTable);
		for (var g = 0; g < testJSON.threadDumps.length; g++) {
			td = testJSON.threadDumps[g];
			// threadDumps.append($('<div class="spacer"><a href="' +
			// testJSON.threadDumps[g].threadDumps + '">' +
			// testJSON.threadDumps[g].threadDumps + '</a></div>'))
			tdTable.append($('<tr><td>' + td.target + '</td> <td>' + td.tier + '</td> <td><a href="' + td.threadDumps + '">thread Dumps</a></td></tr>'));
		}
		artifacts.append(threadDumps);

		eventsTableWrapper.append(artifacts);

	},
	renderGcLogs : function(testJSON) {
		var gcLogs = $('<div class="spacer "/>');
		gcLogs.append($('<div class="medium-boxHeader">gcLogs</div>'));

		var gcLogsTable = $('<table cellpadding="5px" border="1" class="artifactTable" />');
		gcLogsTable.append($('<tr><th>Target</th><th>Tier</th><th>gc.log</th><th>gc report</th><th>statistics</th></tr>'));
		gcLogs.append(gcLogsTable);

		for (var g = 0; g < testJSON.gcLogs.length; g++) {

			var gcTabEntry = $('<tr/>');
			var gcLog = testJSON.gcLogs[g];

			gcTabEntry.append($('<td>' + gcLog.target + '</td>'));
			gcTabEntry.append($('<td><a href="' + ptmTestViewer.artifactsRepository + 'gcLogs/' + gcLog.target + '-' + gcLog.tier + '/report.csv" >' + gcLog.tier + '</a></td>'));
			gcTabEntry.append($('<td><a href="/' + gcLog.gcLogBackup + '">gc.log</a>' + '</td>'));
			gcTabEntry.append($('<td>' + '<a href="/' + gcLog.gcLogReport + '">GC Report</a>' + '</td>'));
			var statsCol = $('<td/>');
			gcTabEntry.append(statsCol);

			var spinner = ptmTestViewer.createSpinner();
			statsCol.append(spinner);
			gcLog.spinner = spinner;

			gcLogsTable.append(gcTabEntry);
			$.ajax({
				type : "GET",
				url : '/' + gcLog.gcLogReport,
				gcLog : gcLog
			}).done(function(data) {
				console.log('got gc.log report');
				gcLog.report = ptmTestViewer.parseGCReport(data);
				gcLog.reportTxt = data;

				if (gcLog.spinner) {
					gcLog.spinner.stop();
					$(gcLog.spinner).replaceWith(ptmTestViewer.renderGCReport(gcLog.report));
					gcLog.spinner = undefined;
				}
			});

		}

		return gcLogs;
	},
	renderGCReport : function(gcReport) {
		var order = new Array();
		order.push("avgfootprintAfterGC");
		order.push("throughput");
		order.push("freedMemoryPerMin");

		order.push("avgPauseInterval");
		order.push("avgPause");
		order.push("maxPause");

		order.push("avgPromotion");
		order.push("avgFreedMemoryByGC");

		order.push("avgFullGCPause");

		order.push("fullGCPause");
		order.push("fullGCPauseCount");
		order.push("fullGCPausePc");

		order.push("avgGCPause");
		order.push("gcPause");
		order.push("gcPausePc");

		order.push("accumPause");
		order.push("footprint");
		order.push("totalTime");
		order.push("dateTimeBegin");
		order.push("dateTimeEnd");

		var gcTable = $('<table cellpadding="5px" border="1" class="artifactTable" />');
		var header = $('<tr/>')
		var row = $('<tr/>')
		gcTable.append(header);
		gcTable.append(row);

		for (var i = 0; i < order.length; i++) {
			header.append($('<th>' + order[i] + '</th>'));
			row.append($('<td>' + gcReport[order[i]] + '</td>'));
		}
		return gcTable
	},
	parseGCReport : function(gcReport) {
		var report = {};

		var reportLines = gcReport.split("\n");
		for (var i = 0; i < reportLines.length; i++) {
			var entry = reportLines[i].split(";");
			report[entry[0]] = entry[1] + " " + entry[2];
		}

		return report;
	},
	parseTest : function(text, eventsTableWrapper) {

		var testJSON = {};

		var testProps = ptmTestViewer.parseProperties(text);
		testJSON.testPropeties = testProps;
		var testId = testJSON.testId = testProps['test.id'];
		var testTag = testJSON.testTag = testProps['test.tag'];
		testJSON.testStart = testProps['test.start'];
		testJSON.testStop = testProps['test.stop'];
		testJSON.testCancel = testProps['test.cancel'];

		testProps.responseText = text;
		testJSON.testName = testName = testProps['test.name'];
		var testTargets = testProps['test.target'].split(";");
		testJSON.targetsList = testTargets;
		testJSON.targets = {};

		var targetsTasks = new Array();
		for (var targetIdx = 0; targetIdx < testTargets.length; targetIdx++) {
			var targetName = testTargets[targetIdx];
			testJSON.targets[targetName] = {};
			var targetAjax = $.ajax({
				type : "GET",
				url : ptmTestViewer.testsRepository + testId + '/' + targetName + '.properties',
				targetName : targetName,

			});

			targetAjax.done(function(data) {
				var targetProps = ptmTestViewer.parseProperties(data);
				targetProps.responseText = data;
				targetProps.targetName = this.targetName;

				testJSON.targets[this.targetName].tiers = targetProps.TIERS.split(";");
				testJSON.targets[this.targetName].targetPropetries = targetProps;

			});
			targetsTasks.push(targetAjax);

		}

		$.when.apply($, targetsTasks).then(function() {
			console.log('got all files');

			ptmTestViewer.getELoggingCharts(testJSON);
			ptmTestViewer.getGcLogs(testJSON);
			ptmTestViewer.getAWR(testJSON);
			ptmTestViewer.getThreadDumps(testJSON);
			ptmTestViewer.getShadowtail(testJSON);
			ptmTestViewer.renderArtifacts(eventsTableWrapper, testJSON)

		});

		return testJSON;
	},
	testSelectionChange : function(testsSelect, eventsTableWrapper) {
		var selctedTest = testsSelect.val();

		$.ajax(ptmTestViewer.testsRepository + selctedTest + '/config.properties').done(function(testData) {
			var test = ptmTestViewer.parseTest(testData, eventsTableWrapper);
			ptmTestViewer.tests[selctedTest] = test;

		});

	},

	getSeriesFromJSON : function(events, property) {
		propert = property.toLowerCase();
		if (!events.series) {
			events.series = {};
		}
		if (!events.series[property]) {
			var series = [];
			events.series[property] = series;
			var i = 0;
			for (i = 0; i < events.AGG.length; i++) {
				series.push([ events.AGG[i].Time, events.AGG[i].data[property] ]);
			}
		}
		return events.series[property];
	},

	getSeriesFromCSV : function(config, csvData) {

		var series = [];

		for (var i = 0; i < csvData.length; i++) {
			var value = csvData[i][config.name];
			if (config.name == "Heap-Memory-Used") {
				value = value / 1024.0 / 1024;
			}

			series.push([ csvData[i].Time, parseFloat(value) ]);
		}

		return series;
	},
	getSeriesFromArray : function(events, property, test) {
		if (!events.series) {
			events.series = {};
		}
		if (!events.series[property]) {
			var series = [];
			events.series[property] = series;
			var i = 0;
			for (i = 0; i < events.AGG.length; i++) {
				series.push([ events.AGG[i][0], events.AGG[i][1][test.config.aggregationTypesIdx[property]] ]);
			}
		}
		return events.series[property];
	},

	redrawChart_fromTableSelection : function(id) {

		var fileNames = [];
		var selections = [];
		for ( var x in ptmTestViewer.selectedCharts) {
			var selectedChart = ptmTestViewer.selectedCharts[x];
			if (selectedChart) {

				var name = selectedChart.name;
				var env = selectedChart.env;
				var logFile = selectedChart.logFile;

				var testName = selectedChart.testName;

				var fileName = '/artifacts/shadowtail/' + env + '/' + logFile;
				selections.push({

					selectedChart : selectedChart,
					fileName : fileName
				});

				fileNames.push(fileName);
			}
		}
		var tasks = new Array();
		for (var i = 0; i < selections.length; i++) {
			var sel = selections[i];

			var task = $.ajax({
				type : "GET",
				url : sel.fileName,
				selection : sel
			});

			task.done(function(data) {
				console.log('got: ' + this.url);
				var csv = $.csv.toObjects(data, {
					separator : " "
				});
				this.csvData = csv;
				// 
			});

			tasks.push(task);

		}

		var xx = $.when.apply($, tasks).then(function() {
			console.log('got all files');
			var chartSeries = [];
			var seriesNames = [];

			for (var i = 0; i < selections.length; i++) {

				var data = selections[i].selectedChart;
				var env = data.env;
				var logFile = data.logFile;
				var name = data.name;

				var csvData = this instanceof Array ? this[i].csvData : this.csvData;
				chartSeries.push(ptmTestViewer.getSeriesFromCSV(data, csvData));
				seriesNames.push({
					rendererOptions : {
						smooth : true
					},
					label : env + ' | ' + logFile + ' | ' + data.name
				});
			}
			ptmTestViewer.createNewCanvas();
			ptmTestViewer.drawChart(id, chartSeries, seriesNames);

		});

	},
	centerOption : function(name) {
		return {
			"sTitle" : name,
			"sClass" : "center"
		};
	},

	prepareColumnNames : function(aggregationTypes) {

		var columns = [

		{
			"sTitle" : "Name"
		} ];

		for ( var aIdx in aggregationTypes) {
			var columnName = aggregationTypes[aIdx];
			if (columnName == 'Name') {
				continue;
			}
			columns.push(ptmTestViewer.centerOption(ptmTestViewer.getColumnName(columnName)));
		}
		return columns;
	},

	getColumnName : function(aggregationType) {
		var columnName = aggregationType ? aggregationType : '';

		if (columnName == 'CNT') {
			columnName = 'Count';
		} else if (columnName == 'AVG') {
			columnName = 'Average';
		} else if (columnName == 'MED') {
			columnName = 'Median';
		} else if (columnName == 'ERR') {
			columnName = 'Errors';
		} else if (columnName == 'ERR') {
			columnName = 'Errors';
		} else if (columnName == 'ST_DEV') {
			columnName = 'St Dev';
		} else if (columnName.indexOf("PERCENTILE_") > -1) {
			columnName = columnName.split("_")[1] + "th";
		}

		return columnName;
	},

	drawEventsTable : function(tableHolder, aDataSet, collumns, testsSelect, logSelect) {

		var testName = testsSelect.val();
		var logName = logSelect.val();

		var columns = ptmTestViewer.prepareColumnNames(collumns);
		var eventsTable = $(tableHolder).dataTable({
			"aaData" : aDataSet,
			"aLengthMenu" : [ [ 5, 10, 20, 40, 80, -1 ], [ 5, 10, 20, 40, 80, "All" ] ],
			"bDestroy" : true,
			"bJQueryUI" : true,
			"sPaginationType" : "full_numbers",
			"aoColumns" : columns
		});

		$(eventsTable.fnGetNodes()).each(function() {
			var sTitle;
			var nTds = $('td', this);
			var name = $(nTds[0]).text();

			var clickParams = {
				'env' : testName,
				'logFile' : logName,
				'name' : name
			};

			$(nTds[0]).click(clickParams, ptmTestViewer.eventSelected)

		});
	},

	eventSelected : function(event) {
		if (!ptmTestViewer.selectedCharts) {
			ptmTestViewer.selectedCharts = {};
		}
		var name = event.data.name;
		var env = event.data.env;
		var logFile = event.data.logFile;

		var key = env + '_' + logFile + '_' + name;
		if (ptmTestViewer.selectedCharts[key]) {
			$(event.target).removeClass('selectedEvent');
			ptmTestViewer.selectedCharts[key] = undefined;
		} else {
			$(event.target).addClass('selectedEvent');
			ptmTestViewer.selectedCharts[key] = event.data;
		}
	}

};
